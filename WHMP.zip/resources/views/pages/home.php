<?php
/** @var CodeVault\View $view */
/** @var array{brandName: string}|null $theme */
$theme ??= ['brandName' => 'CodeVault'];
?>
<div style="display: flex; gap: var(--cv-space-6); align-items: flex-start; max-width: 1400px; margin: 0 auto; padding-top: var(--cv-space-4);">
    <!-- Left Sidebar (Lagom2 style) -->
    <div class="cv-card" style="width: 260px; padding: var(--cv-space-3) 0; flex-shrink: 0; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface); position: sticky; top: var(--cv-space-4);">
        <ul style="list-style: none; padding: 0; margin: 0;">
            <li style="margin-bottom: var(--cv-space-1);">
                <a href="/store" style="display: flex; align-items: center; justify-content: space-between; padding: var(--cv-space-3) var(--cv-space-4); color: var(--cv-text-primary); text-decoration: none; font-weight: 600; font-size: var(--cv-text-sm); transition: background var(--cv-transition-fast);" onmouseover="this.style.background='var(--cv-bg-surface-sunken)'" onmouseout="this.style.background='transparent'">
                    <span style="display: flex; align-items: center; gap: var(--cv-space-3);">
                        <span style="font-size: 1.1rem;">📦</span>
                        <span>Products</span>
                    </span>
                    <span style="font-size: 0.8em; color: var(--cv-text-secondary);">&gt;</span>
                </a>
            </li>
            <li style="margin-bottom: var(--cv-space-1);">
                <a href="/deals" style="display: flex; align-items: center; padding: var(--cv-space-3) var(--cv-space-4); color: var(--cv-text-primary); text-decoration: none; font-weight: 600; font-size: var(--cv-text-sm); transition: background var(--cv-transition-fast);" onmouseover="this.style.background='var(--cv-bg-surface-sunken)'" onmouseout="this.style.background='transparent'">
                    <span style="display: flex; align-items: center; gap: var(--cv-space-3);">
                        <span style="font-size: 1.1rem;">🏷️</span>
                        <span>ZMO Deals</span>
                    </span>
                </a>
            </li>
            <li style="margin-bottom: var(--cv-space-1);">
                <a href="/affiliate" style="display: flex; align-items: center; padding: var(--cv-space-3) var(--cv-space-4); color: var(--cv-text-primary); text-decoration: none; font-weight: 600; font-size: var(--cv-text-sm); transition: background var(--cv-transition-fast);" onmouseover="this.style.background='var(--cv-bg-surface-sunken)'" onmouseout="this.style.background='transparent'">
                    <span style="display: flex; align-items: center; gap: var(--cv-space-3);">
                        <span style="font-size: 1.1rem;">🤝</span>
                        <span>Affiliates</span>
                    </span>
                </a>
            </li>
            <li style="margin-bottom: var(--cv-space-1);">
                <a href="/client/tickets" style="display: flex; align-items: center; justify-content: space-between; padding: var(--cv-space-3) var(--cv-space-4); color: var(--cv-text-primary); text-decoration: none; font-weight: 600; font-size: var(--cv-text-sm); transition: background var(--cv-transition-fast);" onmouseover="this.style.background='var(--cv-bg-surface-sunken)'" onmouseout="this.style.background='transparent'">
                    <span style="display: flex; align-items: center; gap: var(--cv-space-3);">
                        <span style="font-size: 1.1rem;">💬</span>
                        <span>Support</span>
                    </span>
                    <span style="font-size: 0.8em; color: var(--cv-text-secondary);">&gt;</span>
                </a>
            </li>
            <li>
                <a href="https://wa.me/xxx" target="_blank" style="display: flex; align-items: center; padding: var(--cv-space-3) var(--cv-space-4); color: var(--cv-text-primary); text-decoration: none; font-weight: 600; font-size: var(--cv-text-sm); transition: background var(--cv-transition-fast);" onmouseover="this.style.background='var(--cv-bg-surface-sunken)'" onmouseout="this.style.background='transparent'">
                    <span style="display: flex; align-items: center; gap: var(--cv-space-3);">
                        <span style="font-size: 1.1rem;">📞</span>
                        <span>WhatsApp</span>
                    </span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content Area -->
    <div style="flex: 1; min-width: 0;">
        <!-- Terms Warning Banner -->
        <div style="background: rgba(255, 143, 40, 0.08); border: 1px solid var(--cv-color-brand-500); padding: var(--cv-space-4); border-radius: var(--cv-radius-md); display: flex; gap: var(--cv-space-3); margin-bottom: var(--cv-space-6); font-size: var(--cv-text-sm); color: var(--cv-text-primary); align-items: flex-start;">
            <span style="font-size: 1.25rem; line-height: 1;">⚠️</span>
            <div>
                <strong style="display: block; margin-bottom: var(--cv-space-1); font-family: 'Hanken Grotesk', sans-serif;">Read Our Terms of Service Before Purchase Licenses</strong>
                <span style="color: var(--cv-text-secondary); font-size: var(--cv-text-xs);">Please ensure you read <a href="/terms" style="color: var(--cv-color-brand-500); font-weight: 700; text-decoration: none;">terms of services</a> before ordering any license.</span>
            </div>
        </div>

        <h2 style="text-align: center; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-2xl); font-weight: 800; margin-bottom: var(--cv-space-6); color: var(--cv-text-primary);">Products For All Businesses</h2>

        <!-- Product Cards Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: var(--cv-space-4); margin-bottom: var(--cv-space-8);">
            <!-- Card 1 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">📦</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">cPanel/WHM Shared licenses</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$1.99 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 2 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">🖥️</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">Plesk License Bundle VPS/VDS/Dedicated Server</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$7.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 3 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">🌐</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">Webuzo License</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$1.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 4 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">🛠️</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">WP Squared License</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$2.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 5 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">⚡</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">LiteSpeed Workers License</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$3.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 6 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">📝</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">Sitepad License</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$1.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 7 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">🔍</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">ConfigServer eXploit Scanner</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$1.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 8 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">🛡️</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">Fleet SSL License</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$1.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 9 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">💾</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">JetBackup V5 License</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$1.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
            <!-- Card 10 -->
            <div class="cv-card" style="text-align: center; padding: var(--cv-space-5); display: flex; flex-direction: column; align-items: center; border: 1px solid var(--cv-border-default); background: var(--cv-bg-surface);">
                <div style="font-size: 2.25rem; margin-bottom: var(--cv-space-3);">☁️</div>
                <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: var(--cv-text-primary); min-height: 2.5rem; display: flex; align-items: center; justify-content: center;">CloudLinux License</h4>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-top: var(--cv-space-3);">Starting at</div>
                <div style="font-size: var(--cv-text-xl); font-family: 'Hanken Grotesk', sans-serif; font-weight: 800; color: var(--cv-color-brand-500); margin: var(--cv-space-1) 0;">$3.00 USD</div>
                <div style="font-size: var(--cv-text-xs); color: var(--cv-text-secondary); margin-bottom: var(--cv-space-5);">Monthly</div>
                <a href="/store" class="cv-btn" style="width: 100%; text-decoration: none; display: inline-block; font-weight: 700;">Get Started Now</a>
            </div>
        </div>

        <!-- Our Guarantees Section (Blue Block) -->
        <div style="background: #0d6efd; color: #ffffff; border-radius: var(--cv-radius-md); padding: var(--cv-space-6) var(--cv-space-8); margin-top: var(--cv-space-8);">
            <h3 style="text-align: center; margin: 0 0 var(--cv-space-1) 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-xl); font-weight: 800; color: #ffffff;">Our Guarantees</h3>
            <p style="text-align: center; margin: 0 0 var(--cv-space-6) 0; font-size: var(--cv-text-xs); opacity: 0.85;">Learn why we are trusted by over 35,000 clients worldwides</p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: var(--cv-space-6);">
                <!-- G1 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">🛠️</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">24/7 Expert Support</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">Proactively monitors for and alerts you about any malware or downtime.</p>
                    </div>
                </div>
                <!-- G2 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">🚀</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">Fast & Reliable</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">If a scan finds anything, we will safely remove any malware.</p>
                    </div>
                </div>
                <!-- G3 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">🎛️</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">Super Easy to Use</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">Automatically checks your applications to ensure they are up-to-date.</p>
                    </div>
                </div>
                <!-- G4 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">🛡️</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">100% Uptime Guaranteed</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">Get protection against the top 10 web app security flaws.</p>
                    </div>
                </div>
                <!-- G5 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">🔒</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">Secure Servers</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">Our application firewalls protect your website from threats.</p>
                    </div>
                </div>
                <!-- G6 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">💰</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">Money-back Guarantee</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">Daily scans help detect malware early before search engines blacklist.</p>
                    </div>
                </div>
                <!-- G7 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">⚡</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">High Performance</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">Instant and fully automated setup gives you protection immediately.</p>
                    </div>
                </div>
                <!-- G8 -->
                <div style="display: flex; gap: var(--cv-space-3); align-items: flex-start;">
                    <div style="font-size: 1.5rem; background: rgba(255,255,255,0.18); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">📡</div>
                    <div>
                        <h4 style="margin: 0; font-family: 'Hanken Grotesk', sans-serif; font-size: var(--cv-text-sm); font-weight: 700; color: #ffffff;">Content Delivery Network</h4>
                        <p style="margin: var(--cv-space-1) 0 0 0; font-size: var(--cv-text-xs); opacity: 0.85; line-height: 1.4;">Speed up your website by distributing it globally near your users.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
