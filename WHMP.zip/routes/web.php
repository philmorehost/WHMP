<?php

declare(strict_types=1);

use CodeVault\Container;
use CodeVault\Reports\AdminDashboardController;
use CodeVault\Request;
use CodeVault\Response;
use CodeVault\Seo\SeoTags;
use CodeVault\View;

/** @var CodeVault\Router $router */

$router->get('/', function (Request $request, array $params, Container $container): Response {
    /** @var View $view */
    $view = $container->make(View::class);
    /** @var SeoTags $seo */
    $seo = $container->make(SeoTags::class);

    $content = $view->render('pages.home');

    return Response::html($view->render('layouts.client', [
        'title' => 'CodeVault — Web Hosting & Domains',
        'content' => $content,
        'canonicalUrl' => $seo->canonicalUrl('/'),
        'metaDescription' => 'CodeVault provides reliable web hosting, domain registration, and support for your business.',
        'jsonLd' => [$seo->organization()],
    ]));
});

$router->get('/admin', [AdminDashboardController::class, 'index']);
