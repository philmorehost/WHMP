-- CodeVault backup: 2026-07-18T10:16:10+02:00

DROP TABLE IF EXISTS `activity_log`;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `actor_type` enum('admin','client','system') NOT NULL,
  `actor_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `subject_type` varchar(100) DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `description` varchar(500) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_actor` (`actor_type`,`actor_id`),
  KEY `idx_subject` (`subject_type`,`subject_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('32', 'admin', '1', 'order.accepted', 'order', '4', 'Accepted order #4', '127.0.0.1', '2026-07-16 20:24:39');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('33', 'admin', '1', 'invoice.paid', 'invoice', '10', 'Marked invoice #10 as paid (manual, $100 remaining balance)', '127.0.0.1', '2026-07-16 21:20:29');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('34', 'admin', '1', 'invoice.paid', 'invoice', '11', 'Marked invoice #11 as paid (manual, $100 remaining balance)', '127.0.0.1', '2026-07-16 21:32:42');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('35', 'admin', '6', 'gdpr.export_processed', 'client', '28', 'Processed a GDPR data export for client #28', '127.0.0.1', '2026-07-17 21:29:26');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('36', 'admin', '6', 'gdpr.erasure_processed', 'client', '28', 'Processed a GDPR erasure for client #28', '127.0.0.1', '2026-07-17 21:30:08');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('37', 'admin', '6', 'gdpr.request_rejected', 'client', '28', 'Rejected a GDPR export request for client #28', '127.0.0.1', '2026-07-17 21:30:43');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('38', 'admin', '10', 'credit_note.issued', 'client', '31', 'Issued credit note #1 for client #31', '127.0.0.1', '2026-07-18 00:25:28');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('39', 'admin', '11', 'addon.activated', 'addon', '0', 'Activated addon [system-diagnostics]', '127.0.0.1', '2026-07-18 02:17:00');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('40', 'admin', '11', 'addon.deactivated', 'addon', '0', 'Deactivated addon [system-diagnostics]', '127.0.0.1', '2026-07-18 02:17:32');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('41', 'admin', '12', 'widget.activated', 'widget', '0', 'Activated widget [top-clients]', '127.0.0.1', '2026-07-18 08:19:02');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('42', 'admin', '12', 'widget.deactivated', 'widget', '0', 'Deactivated widget [top-clients]', '127.0.0.1', '2026-07-18 08:19:30');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('43', 'admin', '13', 'client.created', 'client', '33', 'Created client r22-reverse-charge@example.test', '127.0.0.1', '2026-07-18 09:13:07');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('44', 'admin', '13', 'client.vat_verified', 'client', '33', 'VIES VAT check for client #33: valid', '127.0.0.1', '2026-07-18 09:14:10');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('45', 'admin', '14', 'quote.created', 'client', '34', 'Created quote #1 for client #34', '127.0.0.1', '2026-07-18 10:14:07');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('46', 'admin', '14', 'quote.sent', 'quote', '1', 'Sent quote #1 to the client', '127.0.0.1', '2026-07-18 10:14:40');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('47', 'admin', '14', 'quote.created', 'client', '34', 'Created quote #2 for client #34', '127.0.0.1', '2026-07-18 10:15:20');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('48', 'admin', '14', 'quote.sent', 'quote', '2', 'Sent quote #2 to the client', '127.0.0.1', '2026-07-18 10:15:21');
INSERT INTO `activity_log` (`id`, `actor_type`, `actor_id`, `action`, `subject_type`, `subject_id`, `description`, `ip_address`, `created_at`) VALUES ('49', 'admin', '14', 'quote.created', 'client', '34', 'Created quote #3 for client #34', '127.0.0.1', '2026-07-18 10:15:55');

DROP TABLE IF EXISTS `addon_modules`;
CREATE TABLE `addon_modules` (
  `slug` varchar(64) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `config` text DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `addon_modules` (`slug`, `enabled`, `config`, `activated_at`, `created_at`, `updated_at`) VALUES ('system-diagnostics', '0', NULL, '2026-07-18 02:17:00', '2026-07-18 02:17:00', '2026-07-18 02:17:32');

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `two_factor_secret` varchar(32) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `display_name` varchar(191) NOT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `login_notify_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_admins_role` (`role_id`),
  CONSTRAINT `fk_admins_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins` (`id`, `username`, `email`, `password_hash`, `two_factor_secret`, `two_factor_enabled`, `two_factor_recovery_codes`, `display_name`, `role_id`, `login_notify_enabled`, `created_at`, `updated_at`) VALUES ('1', 'philadmin', 'philmorehost@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$a3o1c1lBdGhCOXNZZkJjcA$Hmdgwv7NmoW+1S0Xn1Ybkn6Hrx+vTJxA0rU5CwmGRCU', NULL, '0', NULL, 'Phil Admin', '1', '1', '2026-07-15 23:14:28', '2026-07-15 23:14:28');
INSERT INTO `admins` (`id`, `username`, `email`, `password_hash`, `two_factor_secret`, `two_factor_enabled`, `two_factor_recovery_codes`, `display_name`, `role_id`, `login_notify_enabled`, `created_at`, `updated_at`) VALUES ('14', 'r23_testadmin', 'r23-test-admin@example.test', '$argon2id$v=19$m=65536,t=4,p=1$akJsNTNTdldXdHFPbFVWMA$YqspByZkmelGjDC4Wvm64EjH9RCxu7HX2Mjsn7T/p3Q', NULL, '0', NULL, 'R23 Test Admin', '1', '1', '2026-07-18 10:13:23', '2026-07-18 10:13:23');

DROP TABLE IF EXISTS `affiliate_commissions`;
CREATE TABLE `affiliate_commissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(10) unsigned NOT NULL,
  `invoice_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','requested','paid') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_affiliate_commissions_affiliate` (`affiliate_id`),
  KEY `fk_affiliate_commissions_invoice` (`invoice_id`),
  CONSTRAINT `fk_affiliate_commissions_affiliate` FOREIGN KEY (`affiliate_id`) REFERENCES `affiliates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_affiliate_commissions_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `affiliate_payout_requests`;
CREATE TABLE `affiliate_payout_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('requested','approved','rejected','paid') NOT NULL DEFAULT 'requested',
  `requested_at` datetime NOT NULL,
  `processed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_affiliate_payout_requests_affiliate` (`affiliate_id`),
  CONSTRAINT `fk_affiliate_payout_requests_affiliate` FOREIGN KEY (`affiliate_id`) REFERENCES `affiliates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `affiliate_referrals`;
CREATE TABLE `affiliate_referrals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(10) unsigned NOT NULL,
  `referred_client_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_affiliate_referrals_client` (`referred_client_id`),
  KEY `idx_affiliate_referrals_affiliate` (`affiliate_id`),
  CONSTRAINT `fk_affiliate_referrals_affiliate` FOREIGN KEY (`affiliate_id`) REFERENCES `affiliates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_affiliate_referrals_client` FOREIGN KEY (`referred_client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `affiliates`;
CREATE TABLE `affiliates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `code` varchar(32) NOT NULL,
  `status` enum('active','suspended') NOT NULL DEFAULT 'active',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT 10.00,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_affiliates_client` (`client_id`),
  UNIQUE KEY `uniq_affiliates_code` (`code`),
  CONSTRAINT `fk_affiliates_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `published_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_published` (`published_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `backup_runs`;
CREATE TABLE `backup_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` enum('running','success','failed') NOT NULL DEFAULT 'running',
  `file_path` varchar(500) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned DEFAULT NULL,
  `error` text DEFAULT NULL,
  `started_at` datetime NOT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `backup_runs` (`id`, `status`, `file_path`, `size_bytes`, `error`, `started_at`, `finished_at`) VALUES ('3', 'running', NULL, NULL, NULL, '2026-07-18 10:16:10', NULL);

DROP TABLE IF EXISTS `billable_items`;
CREATE TABLE `billable_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `source_type` varchar(50) DEFAULT NULL,
  `source_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `fk_billable_items_invoice` (`invoice_id`),
  CONSTRAINT `fk_billable_items_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_billable_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `canned_replies`;
CREATE TABLE `canned_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `client_contacts`;
CREATE TABLE `client_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  CONSTRAINT `fk_client_contacts_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `client_credit_ledger`;
CREATE TABLE `client_credit_ledger` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `credit_note_id` int(10) unsigned DEFAULT NULL,
  `admin_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `fk_credit_ledger_invoice` (`invoice_id`),
  KEY `fk_ledger_credit_note` (`credit_note_id`),
  CONSTRAINT `fk_credit_ledger_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_credit_ledger_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ledger_credit_note` FOREIGN KEY (`credit_note_id`) REFERENCES `credit_notes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `client_custom_field_values`;
CREATE TABLE `client_custom_field_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `custom_field_id` int(10) unsigned NOT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_client_field` (`client_id`,`custom_field_id`),
  KEY `fk_ccfv_field` (`custom_field_id`),
  CONSTRAINT `fk_ccfv_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ccfv_field` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `client_groups`;
CREATE TABLE `client_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_group_id` int(10) unsigned DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `language_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `two_factor_secret` varchar(32) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `company_name` varchar(191) DEFAULT NULL,
  `address1` varchar(191) DEFAULT NULL,
  `address2` varchar(191) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postcode` varchar(20) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `vat_number` varchar(32) DEFAULT NULL,
  `vat_verified_at` datetime DEFAULT NULL,
  `vat_verified_valid` tinyint(1) DEFAULT NULL,
  `vat_verified_name` varchar(255) DEFAULT NULL,
  `tax_exempt` tinyint(1) NOT NULL DEFAULT 0,
  `phone` varchar(40) DEFAULT NULL,
  `status` enum('active','inactive','closed') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_status` (`status`),
  KEY `fk_clients_group` (`client_group_id`),
  KEY `fk_clients_currency` (`currency_id`),
  KEY `fk_clients_language` (`language_id`),
  CONSTRAINT `fk_clients_currency` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_clients_group` FOREIGN KEY (`client_group_id`) REFERENCES `client_groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_clients_language` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `clients` (`id`, `client_group_id`, `currency_id`, `language_id`, `email`, `password_hash`, `two_factor_secret`, `two_factor_enabled`, `two_factor_recovery_codes`, `first_name`, `last_name`, `company_name`, `address1`, `address2`, `city`, `state`, `postcode`, `country`, `vat_number`, `vat_verified_at`, `vat_verified_valid`, `vat_verified_name`, `tax_exempt`, `phone`, `status`, `notes`, `created_at`, `updated_at`) VALUES ('34', NULL, NULL, NULL, 'r23-test-client@example.test', '$argon2id$v=19$m=65536,t=4,p=1$M3pNOGJNQkR0anRDOFovaA$fd9/rj2rSyVMPDqi+Gvd62TvRYQMKdErXR1uf5/8vSU', NULL, '0', NULL, 'R23', 'TestClient', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, 'active', NULL, '2026-07-18 10:13:40', '2026-07-18 10:13:40');

DROP TABLE IF EXISTS `configurable_option_groups`;
CREATE TABLE `configurable_option_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `configurable_option_pricing`;
CREATE TABLE `configurable_option_pricing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `option_id` int(10) unsigned NOT NULL,
  `billing_cycle` enum('one_time','monthly','quarterly','semi_annually','annually','biennially','triennially') NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_option_cycle` (`option_id`,`billing_cycle`),
  CONSTRAINT `fk_configurable_option_pricing_option` FOREIGN KEY (`option_id`) REFERENCES `configurable_options` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `configurable_options`;
CREATE TABLE `configurable_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `option_group_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group` (`option_group_id`),
  CONSTRAINT `fk_configurable_options_group` FOREIGN KEY (`option_group_id`) REFERENCES `configurable_option_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `credit_note_items`;
CREATE TABLE `credit_note_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(10) unsigned NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_credit_note` (`credit_note_id`),
  CONSTRAINT `credit_note_items_ibfk_1` FOREIGN KEY (`credit_note_id`) REFERENCES `credit_notes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `credit_notes`;
CREATE TABLE `credit_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `reason` varchar(255) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `currency_rate` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `created_by_admin_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_invoice` (`invoice_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `credit_notes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_notes_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `credit_notes_ibfk_3` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `currencies`;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(3) NOT NULL,
  `symbol` varchar(5) NOT NULL,
  `exchange_rate` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `currencies` (`id`, `code`, `symbol`, `exchange_rate`, `is_default`, `created_at`, `updated_at`) VALUES ('1', 'USD', '$', '1.0000', '1', '2026-07-16 12:04:21', '2026-07-16 12:04:21');

DROP TABLE IF EXISTS `custom_fields`;
CREATE TABLE `custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_for` enum('client','product') NOT NULL DEFAULT 'client',
  `name` varchar(191) NOT NULL,
  `type` enum('text','textarea','dropdown','checkbox','password') NOT NULL DEFAULT 'text',
  `options` text DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `admin_only` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_field_for` (`field_for`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `departments` (`id`, `name`, `email`, `created_at`, `updated_at`) VALUES ('1', 'General Support', NULL, '2026-07-16 17:32:29', '2026-07-16 17:32:29');

DROP TABLE IF EXISTS `domains`;
CREATE TABLE `domains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `domain_name` varchar(255) NOT NULL,
  `tld` varchar(30) NOT NULL,
  `registrar_slug` varchar(50) NOT NULL,
  `registrar_domain_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','active','expired','cancelled','transferred_away','grace','redemption') NOT NULL DEFAULT 'pending',
  `registration_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `next_due_date` date DEFAULT NULL,
  `auto_renew` tinyint(1) NOT NULL DEFAULT 1,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `id_protection_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `registrar_lock_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `nameservers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`nameservers`)),
  `provisioning_error` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domain_name` (`domain_name`),
  KEY `idx_client` (`client_id`),
  KEY `idx_due` (`status`,`next_due_date`),
  KEY `fk_domains_order` (`order_id`),
  CONSTRAINT `fk_domains_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_domains_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `download_categories`;
CREATE TABLE `download_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `downloads`;
CREATE TABLE `downloads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_size` int(10) unsigned DEFAULT NULL,
  `download_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  CONSTRAINT `fk_downloads_category` FOREIGN KEY (`category_id`) REFERENCES `download_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `email_log`;
CREATE TABLE `email_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `to_email` varchar(191) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_key` varchar(100) DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `status` enum('queued','sent','failed') NOT NULL DEFAULT 'queued',
  `error` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `email_log` (`id`, `to_email`, `subject`, `template_key`, `client_id`, `status`, `error`, `created_at`, `sent_at`) VALUES ('2', 'campaign-test@example.test', 'Live Test Campaign', NULL, '22', 'sent', NULL, '2026-07-17 15:10:24', '2026-07-17 15:10:24');
INSERT INTO `email_log` (`id`, `to_email`, `subject`, `template_key`, `client_id`, `status`, `error`, `created_at`, `sent_at`) VALUES ('5', 'r22-reverse-charge@example.test', 'Welcome to CodeVault, Reverse!', 'client_welcome', '33', 'sent', NULL, '2026-07-18 09:13:07', '2026-07-18 09:13:07');

DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body_html` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `email_templates` (`id`, `key`, `name`, `subject`, `body_html`, `created_at`, `updated_at`) VALUES ('1', 'client_welcome', 'Client Welcome Email', 'Welcome to {{company_name}}, {{first_name}}!', '<p>Hi {{first_name}},</p><p>Your account with {{company_name}} has been created. You can log in using the email address {{email}}.</p><p>Thanks,<br>{{company_name}}</p>', '2026-07-16 10:11:45', '2026-07-16 10:11:45');
INSERT INTO `email_templates` (`id`, `key`, `name`, `subject`, `body_html`, `created_at`, `updated_at`) VALUES ('2', 'invoice_overdue', 'Invoice Overdue Reminder', 'Invoice INV-{{invoice_id}} is overdue', '<p>Hi {{first_name}},</p><p>Invoice INV-{{invoice_id}} for {{total}} was due on {{due_date}} and is still unpaid. Please log in to your account to settle it.</p><p>Thanks,<br>{{company_name}}</p>', '2026-07-16 12:04:21', '2026-07-16 12:04:21');
INSERT INTO `email_templates` (`id`, `key`, `name`, `subject`, `body_html`, `created_at`, `updated_at`) VALUES ('3', 'service_renewal_reminder', 'Service Renewal Reminder', 'Your {{product_name}} renews on {{due_date}}', '<p>Hi {{first_name}},</p><p>This is a reminder that your service \"{{product_name}}\" is due to renew on {{due_date}} for {{amount}}. No action is needed if you\'d like it to continue — it will renew automatically once the invoice is paid.</p><p>Thanks,<br>{{company_name}}</p>', '2026-07-17 13:41:35', '2026-07-17 13:41:35');
INSERT INTO `email_templates` (`id`, `key`, `name`, `subject`, `body_html`, `created_at`, `updated_at`) VALUES ('4', 'client_password_reset', 'Client Password Reset', 'Reset your {{company_name}} password', '<p>Hi {{first_name}},</p><p>We received a request to reset your password. Click the link below to choose a new one — this link expires in 60 minutes and can only be used once:</p><p><a href=\"{{reset_url}}\">{{reset_url}}</a></p><p>If you didn\'t request this, you can safely ignore this email — your password will not be changed.</p><p>Thanks,<br>{{company_name}}</p>', '2026-07-17 19:09:49', '2026-07-17 19:09:49');
INSERT INTO `email_templates` (`id`, `key`, `name`, `subject`, `body_html`, `created_at`, `updated_at`) VALUES ('5', 'admin_password_reset', 'Admin Password Reset', 'Reset your {{company_name}} admin password', '<p>Hi {{display_name}},</p><p>We received a request to reset your admin password. Click the link below to choose a new one — this link expires in 60 minutes and can only be used once:</p><p><a href=\"{{reset_url}}\">{{reset_url}}</a></p><p>If you didn\'t request this, you can safely ignore this email — your password will not be changed.</p><p>Thanks,<br>{{company_name}}</p>', '2026-07-17 19:09:49', '2026-07-17 19:09:49');

DROP TABLE IF EXISTS `gdpr_requests`;
CREATE TABLE `gdpr_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `type` enum('export','erasure') NOT NULL,
  `status` enum('pending','completed','rejected') NOT NULL DEFAULT 'pending',
  `export_data` longtext DEFAULT NULL,
  `admin_notes` varchar(500) DEFAULT NULL,
  `processed_by_admin_id` int(10) unsigned DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `gdpr_requests_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `import_runs`;
CREATE TABLE `import_runs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `entity_type` varchar(32) NOT NULL DEFAULT 'clients',
  `filename` varchar(255) NOT NULL,
  `total_rows` int(10) unsigned NOT NULL,
  `imported_count` int(10) unsigned NOT NULL,
  `skipped_count` int(10) unsigned NOT NULL,
  `errors` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) unsigned NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_invoice` (`invoice_id`),
  CONSTRAINT `fk_invoice_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `invoice_items` (`id`, `invoice_id`, `description`, `amount`) VALUES ('24', '22', 'Hosting (annual)', '120.00');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `description`, `amount`) VALUES ('25', '22', 'SSL certificate', '15.00');

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `service_id` int(10) unsigned DEFAULT NULL,
  `domain_id` int(10) unsigned DEFAULT NULL,
  `status` enum('unpaid','paid','cancelled','refunded') NOT NULL DEFAULT 'unpaid',
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `currency_rate` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `due_date` date NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `paid_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`),
  KEY `fk_invoices_order` (`order_id`),
  KEY `idx_service_due` (`service_id`,`due_date`),
  KEY `idx_domain_due` (`domain_id`,`due_date`),
  KEY `fk_invoices_currency` (`currency_id`),
  CONSTRAINT `fk_invoices_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_invoices_currency` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_domain` FOREIGN KEY (`domain_id`) REFERENCES `domains` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `invoices` (`id`, `client_id`, `order_id`, `service_id`, `domain_id`, `status`, `subtotal`, `tax_amount`, `total`, `currency_id`, `currency_rate`, `due_date`, `created_at`, `updated_at`, `paid_at`) VALUES ('22', '34', NULL, NULL, NULL, 'unpaid', '135.00', '0.00', '135.00', NULL, '1.0000', '2026-07-18', '2026-07-18 10:14:53', '2026-07-18 10:14:53', NULL);

DROP TABLE IF EXISTS `kb_articles`;
CREATE TABLE `kb_articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `helpful_count` int(10) unsigned NOT NULL DEFAULT 0,
  `unhelpful_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  CONSTRAINT `fk_kb_articles_category` FOREIGN KEY (`category_id`) REFERENCES `kb_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `kb_categories`;
CREATE TABLE `kb_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_rtl` tinyint(1) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `languages` (`id`, `code`, `name`, `is_rtl`, `is_default`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'en', 'English', '0', '1', '1', '2026-07-17 10:49:35', '2026-07-17 10:49:35');
INSERT INTO `languages` (`id`, `code`, `name`, `is_rtl`, `is_default`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'es', 'Español', '0', '0', '1', '2026-07-17 10:49:35', '2026-07-17 10:49:35');
INSERT INTO `languages` (`id`, `code`, `name`, `is_rtl`, `is_default`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'ar', 'العربية', '1', '0', '1', '2026-07-17 10:49:35', '2026-07-17 10:49:35');

DROP TABLE IF EXISTS `license_activation`;
CREATE TABLE `license_activation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(191) NOT NULL,
  `status` enum('pending','active','grace','suspended') NOT NULL DEFAULT 'pending',
  `last_checked_at` datetime DEFAULT NULL,
  `last_valid_at` datetime DEFAULT NULL,
  `cached_response` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `license_activation` (`id`, `domain`, `status`, `last_checked_at`, `last_valid_at`, `cached_response`, `created_at`, `updated_at`) VALUES ('1', '127.0.0.1', 'suspended', '2026-07-18 10:16:10', NULL, '{\"status\":0,\"message\":\"Missing key or domain parameter.\"}', '2026-07-15 23:15:15', '2026-07-18 10:16:10');

DROP TABLE IF EXISTS `mail_campaign_recipients`;
CREATE TABLE `mail_campaign_recipients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `open_token` char(64) NOT NULL,
  `sent_at` datetime DEFAULT NULL,
  `opened_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `open_token` (`open_token`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `fk_mail_campaign_recipients_client` (`client_id`),
  CONSTRAINT `fk_mail_campaign_recipients_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `mail_campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mail_campaign_recipients_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `mail_campaigns`;
CREATE TABLE `mail_campaigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `client_group_id` int(10) unsigned DEFAULT NULL,
  `status` enum('draft','sending','sent') NOT NULL DEFAULT 'draft',
  `scheduled_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_mail_campaigns_group` (`client_group_id`),
  CONSTRAINT `fk_mail_campaigns_group` FOREIGN KEY (`client_group_id`) REFERENCES `client_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `run_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('1', '0001_create_admins_table.php', '2026-07-15 22:14:14');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('2', '0002_create_settings_table.php', '2026-07-15 22:14:14');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('3', '0003_create_license_activation_table.php', '2026-07-15 22:14:14');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('4', '0004_create_security_login_attempts_table.php', '2026-07-15 22:41:03');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('5', '0005_create_security_ip_rules_table.php', '2026-07-15 22:41:03');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('6', '0006_create_security_country_rules_table.php', '2026-07-15 22:41:03');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('7', '0007_create_security_account_locks_table.php', '2026-07-15 22:41:03');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('8', '0008_add_login_notify_to_admins_table.php', '2026-07-15 22:41:03');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('9', '0009_create_client_groups_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('10', '0010_create_clients_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('11', '0011_create_client_contacts_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('12', '0012_create_roles_and_permissions_tables.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('13', '0013_add_role_id_to_admins_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('14', '0014_create_custom_fields_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('15', '0015_create_client_custom_field_values_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('16', '0016_create_email_templates_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('17', '0017_create_email_log_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('18', '0018_create_activity_log_table.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('19', '0019_seed_default_email_templates.php', '2026-07-16 10:11:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('20', '0020_create_product_groups_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('21', '0021_create_products_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('22', '0022_create_product_pricing_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('23', '0023_create_configurable_option_groups_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('24', '0024_create_configurable_options_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('25', '0025_create_configurable_option_pricing_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('26', '0026_create_orders_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('27', '0027_create_order_items_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('28', '0028_create_invoices_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('29', '0029_create_invoice_items_table.php', '2026-07-16 10:48:45');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('30', '0030_create_payment_gateways_table.php', '2026-07-16 10:48:46');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('31', '0031_create_transactions_table.php', '2026-07-16 10:48:46');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('32', '0032_seed_manual_gateway.php', '2026-07-16 10:48:46');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('33', '0033_create_services_table.php', '2026-07-16 12:04:20');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('34', '0034_add_service_id_to_invoices_table.php', '2026-07-16 12:04:21');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('35', '0035_create_tax_rules_table.php', '2026-07-16 12:04:21');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('36', '0036_create_client_credit_ledger_table.php', '2026-07-16 12:04:21');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('37', '0037_create_currencies_table.php', '2026-07-16 12:04:21');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('38', '0038_add_tax_exempt_to_clients_table.php', '2026-07-16 12:04:21');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('39', '0039_add_tax_amount_to_invoices_table.php', '2026-07-16 12:04:21');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('40', '0040_seed_invoice_overdue_email_template.php', '2026-07-16 12:04:21');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('41', '0041_create_server_groups_table.php', '2026-07-16 12:45:23');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('42', '0042_create_servers_table.php', '2026-07-16 12:45:23');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('43', '0043_add_server_group_id_to_products_table.php', '2026-07-16 12:45:24');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('44', '0044_add_provisioning_columns_to_services_table.php', '2026-07-16 12:45:24');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('45', '0045_create_domains_table.php', '2026-07-16 16:56:54');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('46', '0046_add_domain_id_to_invoices_table.php', '2026-07-16 16:56:54');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('47', '0047_create_registrars_table.php', '2026-07-16 16:56:54');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('48', '0048_seed_upperlink_and_connectreseller_registrars.php', '2026-07-16 16:57:53');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('49', '0049_create_departments_table.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('50', '0050_create_tickets_table.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('51', '0051_create_ticket_replies_table.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('52', '0052_create_canned_replies_table.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('53', '0053_create_knowledgebase_tables.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('54', '0054_create_downloads_tables.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('55', '0055_create_announcements_table.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('56', '0056_create_network_issues_table.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('57', '0057_create_billable_items_table.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('58', '0058_seed_default_department.php', '2026-07-16 17:32:29');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('59', '0059_add_fraud_columns_to_orders_table.php', '2026-07-16 19:16:09');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('60', '0060_create_affiliates_table.php', '2026-07-16 19:16:09');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('61', '0061_create_affiliate_referrals_table.php', '2026-07-16 19:16:09');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('62', '0062_create_affiliate_commissions_table.php', '2026-07-16 19:16:09');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('63', '0063_create_affiliate_payout_requests_table.php', '2026-07-16 19:16:09');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('64', '0064_add_upsell_columns_to_products_table.php', '2026-07-16 19:16:09');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('65', '0065_drop_balance_column_from_affiliates_table.php', '2026-07-16 19:28:08');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('66', '0066_add_requested_status_to_affiliate_commissions_table.php', '2026-07-16 20:17:37');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('67', '0067_add_currency_columns_to_orders_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('68', '0068_add_currency_columns_to_invoices_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('69', '0069_add_currency_id_to_clients_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('70', '0070_create_languages_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('71', '0071_create_translation_overrides_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('72', '0072_add_language_id_to_clients_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('73', '0073_create_notification_endpoints_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('74', '0074_create_backup_runs_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('75', '0075_create_mail_campaigns_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('76', '0076_create_mail_campaign_recipients_table.php', '2026-07-17 10:49:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('77', '0077_add_renewal_reminded_at_to_services_table.php', '2026-07-17 13:41:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('78', '0078_seed_service_renewal_reminder_email_template.php', '2026-07-17 13:41:35');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('79', '0079_seed_paystack_and_flutterwave_gateways.php', '2026-07-17 16:45:41');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('80', '0080_add_two_factor_columns_to_admins_table.php', '2026-07-17 17:45:47');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('81', '0081_add_two_factor_columns_to_clients_table.php', '2026-07-17 17:45:47');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('82', '0082_create_password_reset_tokens_table.php', '2026-07-17 19:09:49');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('83', '0083_seed_password_reset_email_templates.php', '2026-07-17 19:09:49');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('84', '0084_create_gdpr_requests_table.php', '2026-07-17 20:12:58');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('85', '0085_create_import_runs_table.php', '2026-07-17 20:57:48');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('86', '0086_create_credit_notes_tables.php', '2026-07-17 23:16:36');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('87', '0087_add_credit_note_id_to_client_credit_ledger_table.php', '2026-07-17 23:16:37');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('88', '0088_create_addon_modules_table.php', '2026-07-18 01:10:54');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('89', '0089_create_widget_modules_table.php', '2026-07-18 07:14:59');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('90', '0090_add_vat_fields_to_clients_table.php', '2026-07-18 07:54:34');
INSERT INTO `migrations` (`id`, `migration`, `run_at`) VALUES ('91', '0091_create_quotes_tables.php', '2026-07-18 08:58:26');

DROP TABLE IF EXISTS `network_issues`;
CREATE TABLE `network_issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` enum('investigating','identified','monitoring','resolved') NOT NULL DEFAULT 'investigating',
  `started_at` datetime NOT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `notification_endpoints`;
CREATE TABLE `notification_endpoints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('slack','webhook') NOT NULL,
  `name` varchar(191) NOT NULL,
  `url` varchar(500) NOT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `events` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `product_name` varchar(191) NOT NULL,
  `billing_cycle` enum('one_time','monthly','quarterly','semi_annually','annually','biennially','triennially') NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL,
  `setup_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `configurable_options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configurable_options`)),
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `fk_order_items_product` (`product_id`),
  CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `status` enum('pending','active','cancelled','fraud') NOT NULL DEFAULT 'pending',
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `currency_rate` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `fraud_score` decimal(5,2) DEFAULT NULL,
  `fraud_reasons` text DEFAULT NULL,
  `fraud_reviewed_by` int(10) unsigned DEFAULT NULL,
  `fraud_reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`),
  KEY `fk_orders_currency` (`currency_id`),
  CONSTRAINT `fk_orders_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_orders_currency` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_type` enum('admin','client') NOT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_account` (`account_type`,`account_id`),
  KEY `idx_token_hash` (`token_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `payment_gateways`;
CREATE TABLE `payment_gateways` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(50) NOT NULL,
  `name` varchar(191) NOT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_gateways` (`id`, `slug`, `name`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`) VALUES ('1', 'manual', 'Bank Transfer / Manual Payment', NULL, '1', '0', '2026-07-16 10:48:46', '2026-07-16 11:50:07');
INSERT INTO `payment_gateways` (`id`, `slug`, `name`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`) VALUES ('2', 'paystack', 'Paystack', NULL, '0', '1', '2026-07-17 16:45:41', '2026-07-17 18:16:13');
INSERT INTO `payment_gateways` (`id`, `slug`, `name`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`) VALUES ('3', 'flutterwave', 'Flutterwave', NULL, '0', '2', '2026-07-17 16:45:41', '2026-07-17 16:45:41');

DROP TABLE IF EXISTS `product_configurable_option_groups`;
CREATE TABLE `product_configurable_option_groups` (
  `product_id` int(10) unsigned NOT NULL,
  `option_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`product_id`,`option_group_id`),
  KEY `fk_pcog_group` (`option_group_id`),
  CONSTRAINT `fk_pcog_group` FOREIGN KEY (`option_group_id`) REFERENCES `configurable_option_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pcog_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `product_groups`;
CREATE TABLE `product_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `product_pricing`;
CREATE TABLE `product_pricing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `billing_cycle` enum('one_time','monthly','quarterly','semi_annually','annually','biennially','triennially') NOT NULL,
  `setup_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_product_cycle` (`product_id`,`billing_cycle`),
  CONSTRAINT `fk_product_pricing_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_group_id` int(10) unsigned NOT NULL,
  `server_group_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','hidden') NOT NULL DEFAULT 'active',
  `is_upsell` tinyint(1) NOT NULL DEFAULT 0,
  `upsell_pitch` varchar(255) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group` (`product_group_id`),
  KEY `fk_products_server_group` (`server_group_id`),
  CONSTRAINT `fk_products_group` FOREIGN KEY (`product_group_id`) REFERENCES `product_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_products_server_group` FOREIGN KEY (`server_group_id`) REFERENCES `server_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `quote_items`;
CREATE TABLE `quote_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quote_id` int(10) unsigned NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_quote` (`quote_id`),
  CONSTRAINT `quote_items_ibfk_1` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `quote_items` (`id`, `quote_id`, `description`, `amount`) VALUES ('1', '1', 'Hosting (annual)', '120.00');
INSERT INTO `quote_items` (`id`, `quote_id`, `description`, `amount`) VALUES ('2', '1', 'SSL certificate', '15.00');
INSERT INTO `quote_items` (`id`, `quote_id`, `description`, `amount`) VALUES ('3', '2', 'Item', '50.00');

DROP TABLE IF EXISTS `quotes`;
CREATE TABLE `quotes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` enum('draft','sent','accepted','declined','expired') NOT NULL DEFAULT 'draft',
  `valid_until` date DEFAULT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `currency_rate` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `created_by_admin_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`),
  KEY `currency_id` (`currency_id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `quotes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quotes_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quotes_ibfk_3` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `quotes` (`id`, `client_id`, `subject`, `status`, `valid_until`, `total`, `currency_id`, `currency_rate`, `invoice_id`, `created_by_admin_id`, `created_at`, `updated_at`) VALUES ('1', '34', 'Website hosting + SSL bundle', 'accepted', '2027-01-01', '135.00', NULL, '1.0000', '22', '14', '2026-07-18 10:14:07', '2026-07-18 10:14:53');
INSERT INTO `quotes` (`id`, `client_id`, `subject`, `status`, `valid_until`, `total`, `currency_id`, `currency_rate`, `invoice_id`, `created_by_admin_id`, `created_at`, `updated_at`) VALUES ('2', '34', 'Second quote (to decline)', 'declined', NULL, '50.00', NULL, '1.0000', NULL, '14', '2026-07-18 10:15:20', '2026-07-18 10:15:22');

DROP TABLE IF EXISTS `registrars`;
CREATE TABLE `registrars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(50) NOT NULL,
  `name` varchar(191) NOT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `registrars` (`id`, `slug`, `name`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`) VALUES ('1', 'local', 'Local (no external registry)', NULL, '1', '0', '2026-07-16 16:56:54', '2026-07-16 16:56:54');
INSERT INTO `registrars` (`id`, `slug`, `name`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`) VALUES ('2', 'upperlink', 'Upperlink', NULL, '0', '1', '2026-07-16 16:57:53', '2026-07-16 16:57:53');
INSERT INTO `registrars` (`id`, `slug`, `name`, `config`, `is_enabled`, `sort_order`, `created_at`, `updated_at`) VALUES ('3', 'connectreseller', 'ConnectReseller', NULL, '0', '2', '2026-07-16 16:57:53', '2026-07-16 16:57:53');

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_key` varchar(100) NOT NULL,
  PRIMARY KEY (`role_id`,`permission_key`),
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_super_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `roles` (`id`, `name`, `is_super_admin`, `created_at`, `updated_at`) VALUES ('1', 'Full Administrator', '1', '2026-07-16 10:11:45', '2026-07-16 10:11:45');

DROP TABLE IF EXISTS `security_account_locks`;
CREATE TABLE `security_account_locks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `locked_at` datetime NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admin` (`admin_id`),
  CONSTRAINT `fk_security_account_locks_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `security_country_rules`;
CREATE TABLE `security_country_rules` (
  `country_code` char(2) NOT NULL,
  `policy` enum('whitelisted','not_specified','blacklisted') NOT NULL DEFAULT 'not_specified',
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `security_ip_rules`;
CREATE TABLE `security_ip_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `policy` enum('blacklisted','whitelisted') DEFAULT NULL,
  `tier` enum('day','week','month','year') DEFAULT NULL,
  `source` enum('auto','manual') NOT NULL DEFAULT 'auto',
  `reason` varchar(255) DEFAULT NULL,
  `admin_id` int(10) unsigned DEFAULT NULL,
  `clean_session_count` int(10) unsigned NOT NULL DEFAULT 0,
  `block_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `idx_policy` (`policy`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `security_ip_rules` (`id`, `ip_address`, `policy`, `tier`, `source`, `reason`, `admin_id`, `clean_session_count`, `block_count`, `created_at`, `updated_at`, `expires_at`) VALUES ('11', '127.0.0.1', 'whitelisted', NULL, 'auto', '5 consecutive clean sessions.', NULL, '5', '0', '2026-07-18 02:16:40', '2026-07-18 10:14:39', NULL);

DROP TABLE IF EXISTS `security_login_attempts`;
CREATE TABLE `security_login_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `country_code` char(2) DEFAULT NULL,
  `successful` tinyint(1) NOT NULL DEFAULT 0,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ip_created` (`ip_address`,`created_at`),
  KEY `idx_username_created` (`username`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('1', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-15 23:41:45');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('2', 'philadmin', '127.0.0.1', NULL, '0', NULL, '2026-07-15 23:42:01');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('3', 'philadmin', '127.0.0.1', NULL, '0', NULL, '2026-07-15 23:42:02');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('4', 'philadmin', '127.0.0.1', NULL, '0', NULL, '2026-07-15 23:42:03');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('5', 'philadmin', '127.0.0.1', NULL, '0', NULL, '2026-07-15 23:42:04');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('6', 'philadmin', '127.0.0.1', NULL, '0', NULL, '2026-07-15 23:42:06');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('7', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-15 23:43:25');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('8', 'totally-not-a-real-user', '127.0.0.1', NULL, '0', NULL, '2026-07-15 23:43:47');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('9', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 11:12:11');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('10', 'agent1', '127.0.0.1', NULL, '1', NULL, '2026-07-16 11:12:37');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('11', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 11:49:10');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('12', 'carla@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-16 11:49:53');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('13', 'limiteduser', '127.0.0.1', NULL, '1', NULL, '2026-07-16 11:50:46');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('14', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 13:04:33');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('15', 'ngozi@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-16 13:05:14');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('16', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 13:45:41');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('17', 'tunde@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-16 13:46:11');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('18', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 17:57:14');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('19', 'amaka@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-16 17:57:16');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('20', 'limiteduser', '127.0.0.1', NULL, '0', NULL, '2026-07-16 17:59:41');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('21', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 18:34:46');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('22', 'cvtestclient@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 18:35:20');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('23', 'cvtestclient@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 18:35:45');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('24', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 18:37:27');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('25', 'cvtestclient@example.com', '127.0.0.1', NULL, '0', NULL, '2026-07-16 18:49:44');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('26', 'cvtestclient@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 18:50:05');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('27', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 18:50:06');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('28', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 18:59:14');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('29', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 19:09:18');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('30', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 19:18:49');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('31', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 19:30:45');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('32', 'cvaitest@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 19:30:47');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('33', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 19:41:15');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('34', 'cvaitest2@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 19:41:17');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('35', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 20:01:30');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('36', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 20:07:45');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('37', 'cvfinalsweep@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 20:07:57');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('38', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 20:23:09');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('39', 'cvfraudtest@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 20:23:50');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('40', 'cvaffiliate@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:19:18');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('41', 'cvreferred@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:19:32');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('42', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:19:46');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('43', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:31:54');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('44', 'cvreporttest@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:32:11');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('45', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:47:03');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('46', 'cvupselltest@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:47:50');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('47', 'cvfinalsweepr9@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 21:57:37');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('48', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 22:36:10');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('49', 'cvaifollowup@example.com', '127.0.0.1', NULL, '1', NULL, '2026-07-16 23:25:45');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('50', 'philadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-16 23:54:56');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('51', 'currency-audit@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 12:19:03');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('52', 'currency-audit2@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 12:30:19');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('53', 'pdf-test@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 13:18:41');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('54', 'notif-test@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 14:04:10');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('55', 'campaign-test@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 15:09:51');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('56', 'race-a@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 15:49:32');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('57', 'race-b@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 15:49:33');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('58', 'admin', '127.0.0.1', NULL, '0', NULL, '2026-07-17 16:40:20');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('59', 'pay-test@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-17 18:16:53');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('85', '', '127.0.0.1', NULL, '0', NULL, '2026-07-18 02:13:27');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('86', 'r20_testadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-18 02:16:40');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('87', 'r21_testadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-18 08:18:42');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('88', 'r22_testadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-18 09:12:42');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('89', 'r23_testadmin', '127.0.0.1', NULL, '1', NULL, '2026-07-18 10:13:52');
INSERT INTO `security_login_attempts` (`id`, `username`, `ip_address`, `country_code`, `successful`, `user_agent`, `created_at`) VALUES ('90', 'r23-test-client@example.test', '127.0.0.1', NULL, '1', NULL, '2026-07-18 10:14:39');

DROP TABLE IF EXISTS `server_groups`;
CREATE TABLE `server_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `server_group_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `hostname` varchar(191) NOT NULL,
  `module_slug` varchar(50) NOT NULL,
  `api_username` varchar(191) DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `api_port` int(10) unsigned DEFAULT NULL,
  `use_ssl` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group` (`server_group_id`),
  CONSTRAINT `fk_servers_group` FOREIGN KEY (`server_group_id`) REFERENCES `server_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `server_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `product_name` varchar(191) NOT NULL,
  `billing_cycle` enum('one_time','monthly','quarterly','semi_annually','annually','biennially','triennially') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','active','suspended','cancelled','terminated') NOT NULL DEFAULT 'pending',
  `provisioning_error` text DEFAULT NULL,
  `next_due_date` date NOT NULL,
  `renewal_reminded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_due` (`status`,`next_due_date`),
  KEY `fk_services_order` (`order_id`),
  KEY `fk_services_product` (`product_id`),
  KEY `fk_services_server` (`server_id`),
  CONSTRAINT `fk_services_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_services_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_services_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_services_server` FOREIGN KEY (`server_id`) REFERENCES `servers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `key` varchar(191) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES ('tax.seller_country_code', '', '2026-07-18 09:12:53');
INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES ('theme.brand_name', 'CodeVault', '2026-07-17 14:30:02');
INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES ('theme.logo_url', '', '2026-07-17 14:30:02');
INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES ('theme.primary_color', '#2f6fed', '2026-07-17 14:30:02');

DROP TABLE IF EXISTS `tax_rules`;
CREATE TABLE `tax_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` char(2) NOT NULL,
  `state` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT 'Tax',
  `rate` decimal(5,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_country_state` (`country_code`,`state`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `ticket_replies`;
CREATE TABLE `ticket_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `author_type` enum('client','admin') NOT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `author_name` varchar(191) NOT NULL,
  `message` text NOT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ticket` (`ticket_id`),
  CONSTRAINT `fk_ticket_replies_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `department_id` int(10) unsigned NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` enum('open','answered','customer-reply','closed') NOT NULL DEFAULT 'open',
  `priority` enum('low','medium','high') NOT NULL DEFAULT 'medium',
  `assigned_admin_id` int(10) unsigned DEFAULT NULL,
  `satisfaction_rating` tinyint(3) unsigned DEFAULT NULL,
  `last_reply_at` datetime DEFAULT NULL,
  `last_reply_by` enum('client','admin') DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_id`),
  KEY `idx_status` (`status`),
  KEY `idx_department` (`department_id`),
  KEY `fk_tickets_assigned_admin` (`assigned_admin_id`),
  CONSTRAINT `fk_tickets_assigned_admin` FOREIGN KEY (`assigned_admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tickets_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tickets_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) unsigned NOT NULL,
  `gateway_slug` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('completed','refunded','failed') NOT NULL DEFAULT 'completed',
  `gateway_transaction_id` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_invoice` (`invoice_id`),
  CONSTRAINT `fk_transactions_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `translation_overrides`;
CREATE TABLE `translation_overrides` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(10) unsigned NOT NULL,
  `key` varchar(191) NOT NULL,
  `value` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_language_key` (`language_id`,`key`),
  CONSTRAINT `fk_translation_overrides_language` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `widget_modules`;
CREATE TABLE `widget_modules` (
  `slug` varchar(64) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `config` text DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `widget_modules` (`slug`, `enabled`, `config`, `activated_at`, `created_at`, `updated_at`) VALUES ('top-clients', '0', NULL, '2026-07-18 08:19:02', '2026-07-18 08:19:02', '2026-07-18 08:19:30');

